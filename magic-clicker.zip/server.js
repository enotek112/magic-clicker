
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mongoose = require('mongoose');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

mongoose.connect('mongodb://localhost:27017/magicClicker', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const playerSchema = new mongoose.Schema({
    username: String,
    energy: Number,
    energyPerClick: Number,
    upgradeCost: Number,
    bossCost: Number,
    enemyLevel: Number,
    items: [String],
    score: { type: Number, default: 0 }
});
const Player = mongoose.model('Player', playerSchema);

const messageSchema = new mongoose.Schema({
    username: String,
    message: String,
    timestamp: { type: Date, default: Date.now }
});
const Message = mongoose.model('Message', messageSchema);

app.use(express.static('public'));

io.on('connection', (socket) => {
    Message.find().sort({ timestamp: -1 }).limit(10).exec((err, messages) => {
        socket.emit('chatMessages', messages);
    });

    socket.on('sendMessage', (data) => {
        const message = new Message(data);
        message.save().then(() => io.emit('newMessage', data));
    });

    socket.on('saveProgress', async (data) => {
        const player = await Player.findOneAndUpdate(
            { username: data.username },
            data,
            { upsert: true, new: true }
        );
        socket.emit('progressSaved', player);
    });

    socket.on('loadProgress', async (username) => {
        const player = await Player.findOne({ username });
        socket.emit('loadProgress', player || {
            energy: 0, energyPerClick: 1, upgradeCost: 10,
            bossCost: 100, enemyLevel: 1, items: []
        });
    });

    socket.on('updateScore', async (data) => {
        const player = await Player.findOne({ username: data.username });
        if (player) {
            player.score = data.score;
            await player.save();
            io.emit('scoreUpdated', player);
        }
    });

    socket.on('getLeaderboard', async () => {
        const leaderboard = await Player.find().sort({ score: -1 }).limit(5);
        socket.emit('leaderboard', leaderboard);
    });

    socket.on('newItem', async (data) => {
        const player = await Player.findOne({ username: data.username });
        if (player && !player.items.includes(data.item)) {
            player.items.push(data.item);
            await player.save();
            io.emit('newItem', { username: data.username, item: data.item });
        }
    });
});

server.listen(3000, () => {
    console.log('Сервер запущен на порту 3000');
});
